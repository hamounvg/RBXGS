<?php
$port = 64989;
$logFile = __DIR__ . "/rbxgs_log.txt"; // log file in same directory

// Create TCP socket
$sock = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
if ($sock === false) {
    die("socket_create() failed: " . socket_strerror(socket_last_error()) . "\n");
}

if (socket_bind($sock, '0.0.0.0', $port) === false) {
    die("socket_bind() failed: " . socket_strerror(socket_last_error($sock)) . "\n");
}

if (socket_listen($sock, 5) === false) {
    die("socket_listen() failed: " . socket_strerror(socket_last_error($sock)) . "\n");
}

echo "Listening on port $port...\n";

while (true) {
    $client = socket_accept($sock);
    if ($client === false) {
        echo "socket_accept() failed: " . socket_strerror(socket_last_error($sock)) . "\n";
        continue;
    }

    // Read up to 4KB of data
    $input = socket_read($client, 4096, PHP_NORMAL_READ);
    if ($input !== false) {
        $input = trim($input);
        echo "Received (raw): $input\n";

        $decoded = base64_decode($input, true);
        if ($decoded !== false) {
            echo "Decoded: $decoded\n";
        } else {
            echo "Not valid Base64.\n";
        }

        // Append to log file
        $logEntry = "[" . date("Y-m-d H:i:s") . "] RAW: $input\n";
        if ($decoded !== false) {
            $logEntry .= "Decoded: $decoded\n";
        }
        $logEntry .= "-----------------------------\n";

        file_put_contents($logFile, $logEntry, FILE_APPEND);
    }

    socket_close($client);
}

socket_close($sock);
?>
