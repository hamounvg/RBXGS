<?php
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$file = __DIR__ . '/../thumbs/' . $id . '.png';

if (file_exists($file)) {
    header("Content-Type: image/png");
    readfile($file);
} else {
    $im = imagecreatetruecolor(420, 420);
    $bg = imagecolorallocate($im, 200, 200, 200);
    $text_color = imagecolorallocate($im, 0, 0, 0);
    imagefilledrectangle($im, 0, 0, 420, 420, $bg);
    imagestring($im, 5, 150, 200, "Pending Render", $text_color);
    header("Content-Type: image/png");
    imagepng($im);
    imagedestroy($im);
}
?>