<?php   
require '../IDE/dbconnect.php';
  
$mysqli = new mysqli("localhost", "root", "", "users");


$UserID =  $_SESSION['uzerid'] ;




$colorselection = "SELECT left arm, right arm, left leg, right leg, head, torso, id
        FROM usercolordata 
        WHERE id = $UserID";







?>