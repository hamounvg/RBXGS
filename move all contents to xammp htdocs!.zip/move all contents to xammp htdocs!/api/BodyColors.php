<?php
// api/BodyColors.php
header("Content-Type: text/plain");

$userId = isset($_GET['userId']) ? (int)$_GET['userId'] : 1;
$dbPath = __DIR__ . '/../data/users.json';

$tshirt = $_GET['id'];




$colors = [
    "headColor"   => 24, 
    "torsoColor"  => 23, 
    "lArmColor"   => 24, 
    "rArmColor"   => 24, 
    "lLegColor"   => 119, 
    "rLegColor"   => 119
];

if (file_exists($dbPath)) {
    $json = json_decode(file_get_contents($dbPath), true);
    
    if (isset($json[$userId])) {
        $user = $json[$userId];
        foreach ($colors as $key => $val) {
            if (isset($user[$key])) {
                $colors[$key] = (int)$user[$key];
            }
        }
    }
}

echo '<?xml version="1.0" encoding="utf-8"?>
<roblox xmlns:xmime="http://www.w3.org/2005/05/xmlmime" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="http://www.roblox.com/roblox.xsd" version="4">
	<External>null</External>
	<External>nil</External>
	<Item class="BodyColors">
		<Properties>
			<string name="Name">Body Colors</string>
			<int name="HeadColor">'.$colors['headColor'].'</int>
			<int name="TorsoColor">'.$colors['torsoColor'].'</int>
			<int name="LeftArmColor">'.$colors['lArmColor'].'</int>
			<int name="RightArmColor">'.$colors['rArmColor'].'</int>
			<int name="LeftLegColor">'.$colors['lLegColor'].'</int>
			<int name="RightLegColor">'.$colors['rLegColor'].'</int>
		</Properties>
	</Item>
    <Item class="ShirtGraphic">
        <Properties>
            <string name="Name">ShirtGraphic</string>
            <Content name="Graphic">
              <url>http://localhost/assets/'.$tshirt.'.png</url>
            </Content>
        </Properties>
    </Item>
    
</roblox>';
?>