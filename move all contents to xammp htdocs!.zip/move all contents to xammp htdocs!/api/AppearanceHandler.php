<?php
// api/AppearanceHandler.php
error_reporting(0);
ob_clean();
header("Content-Type: text/xml");

$userId = isset($_GET['userId']) ? (int)$_GET['userId'] : 1;
$dbPath = __DIR__ . '/../data/users.json';

$data = [
    "head" => 26, "torso" => 23, "larm" => 24, "rarm" => 24, 
    "lleg" => 119, "rleg" => 119, "tshirt" => 1, 
    "tmode" => "direct"
];

if (file_exists($dbPath)) {
    $json = json_decode(file_get_contents($dbPath), true);
    if (isset($json[$userId])) {
        $data = array_merge($data, $json[$userId]);
    }
}

echo '<?xml version="1.0" encoding="utf-8"?>';
?>
<roblox xmlns:xmime="http://www.w3.org/2005/05/xmlmime" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="http://www.roblox.com/roblox.xsd" version="4">
	<External>null</External>
	<External>nil</External>
	<Item class="BodyColors">
		<Properties>
			<string name="Name">Body Colors</string>
			<int name="HeadColor"><?php echo $data['head']; ?></int>
			<int name="TorsoColor"><?php echo $data['torso']; ?></int>
			<int name="LeftArmColor"><?php echo $data['larm']; ?></int>
			<int name="RightArmColor"><?php echo $data['rarm']; ?></int>
			<int name="LeftLegColor"><?php echo $data['lleg']; ?></int>
			<int name="RightLegColor"><?php echo $data['rleg']; ?></int>
		</Properties>
	</Item>
    
    <?php if(!empty($data['tshirt']) && $data['tshirt'] != "0"): ?>
    <Item class="ShirtGraphic">
        <Properties>
            <string name="Name">ShirtGraphic</string>
            <Content name="Graphic">
                <url><?php 
                    if ($data['tmode'] == "direct") {
                          echo (int)$data['tshirt'] . ".png";
                    } else {
                        echo (int)$data['tshirt'] . ".png";
                    }
                ?></url>
            </Content>
        </Properties>
    </Item>
    <?php endif; ?>
</roblox>