<?php

// Your PHP array (can be empty or filled)
$hatdata = []; // ← if this is empty, load JSON

// Load JSON only if PHP array is empty
if (empty($hatdata)) {
    $jsonFile = "attachments.json";

    if (file_exists($jsonFile)) {
        $json = json_decode(file_get_contents($jsonFile), true);

        if (is_array($json)) {
            $hatdata = $json; // JSON becomes the array
        }
    }
}

// Now $hatdata ALWAYS has something:
// - JSON data if PHP array was empty
// - PHP defaults if not empty
// - Empty array if both are empty (still safe)
