<?php
header("Content-Type: text/plain");

$hatdata = [
   
];

if (empty($hatdata)) {
    $jsonFile = "hats.json";

    if (file_exists($jsonFile)) {
        $json = file_get_contents($jsonFile);
        $data = json_decode($json, true);

        if (is_array($data)) {
            $hatdata = $data;
        }
    }
}

$hat = $_GET['hat'];
$hatx = number_format((float)$hatdata[$hat]["AttachmentX"], 6, '.', '');
$haty = number_format((float)$hatdata[$hat]["AttachmentY"], 6, '.', '');
$hatz = number_format((float)$hatdata[$hat]["AttachmentZ"], 6, '.', '');

$hatmesh = "http://gldblx.net/HatData/HatDataMesh" .trim("/ ") . $hat . ".mesh";
$hattexture = "http://gldblx.net/HatData/HatDataTexture" .trim("/ ") . $hat . ".png";


$xml = '<?xml version="1.0" encoding="utf-8"?>
<roblox xmlns:xmime="http://www.w3.org/2005/05/xmlmime" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="http://www.roblox.com/roblox.xsd" version="4">
	<External>null</External>
	<External>nil</External>
	<Item class="Hat" referent="RBX0">
		<Properties>
			<bool name="Archivable">true</bool>
			<CoordinateFrame name="AttachmentPoint">
				<X>{hatx}</X>
				<Y>{haty}</Y>
				<Z>{hatz}</Z>
				<R00>1</R00>
				<R01>0</R01>
				<R02>0</R02>
				<R10>0</R10>
				<R11>1</R11>
				<R12>0</R12>
				<R20>0</R20>
				<R21>0</R21>
				<R22>1</R22>
			</CoordinateFrame>
			<string name="Name">HAT</string>
		</Properties>
		<Item class="Part" referent="RBX1">
			<Properties>
				<bool name="Anchored">false</bool>
				<bool name="Archivable">true</bool>
				<float name="BackParamA">-0.5</float>
				<float name="BackParamB">0.5</float>
				<token name="BackSurface">0</token>
				<token name="BackSurfaceInput">0</token>
				<float name="BottomParamA">-0.5</float>
				<float name="BottomParamB">0.5</float>
				<token name="BottomSurface">0</token>
				<token name="BottomSurfaceInput">0</token>
				<int name="BrickColor">194</int>
				<CoordinateFrame name="CFrame">
					<X>-17.5</X>
					<Y>0.600000024</Y>
					<Z>15.5</Z>
					<R00>1</R00>
					<R01>0</R01>
					<R02>0</R02>
					<R10>0</R10>
					<R11>1</R11>
					<R12>0</R12>
					<R20>0</R20>
					<R21>0</R21>
					<R22>1</R22>
				</CoordinateFrame>
				<bool name="CanCollide">true</bool>
				<float name="Elasticity">0.5</float>
				<token name="FormFactor">2</token>
				<float name="Friction">0.300000012</float>
				<float name="FrontParamA">-0.5</float>
				<float name="FrontParamB">0.5</float>
				<token name="FrontSurface">0</token>
				<token name="FrontSurfaceInput">0</token>
				<float name="LeftParamA">-0.5</float>
				<float name="LeftParamB">0.5</float>
				<token name="LeftSurface">0</token>
				<token name="LeftSurfaceInput">0</token>
				<bool name="Locked">true</bool>
				<token name="Material">256</token>
				<string name="Name">Handle</string>
				<float name="Reflectance">0</float>
				<float name="RightParamA">-0.5</float>
				<float name="RightParamB">0.5</float>
				<token name="RightSurface">0</token>
				<token name="RightSurfaceInput">0</token>
				<Vector3 name="RotVelocity">
					<X>0</X>
					<Y>0</Y>
					<Z>0</Z>
				</Vector3>
				<float name="TopParamA">-0.5</float>
				<float name="TopParamB">0.5</float>
				<token name="TopSurface">0</token>
				<token name="TopSurfaceInput">0</token>
				<float name="Transparency">0</float>
				<Vector3 name="Velocity">
					<X>0</X>
					<Y>0</Y>
					<Z>0</Z>
				</Vector3>
				<token name="shape">1</token>
				<Vector3 name="size">
					<X>1</X>
					<Y>0.400000006</Y>
					<Z>1</Z>
				</Vector3>
			</Properties>
			<Item class="SpecialMesh" referent="RBX2">
				<Properties>
					<bool name="Archivable">true</bool>
					<token name="LODX">2</token>
					<token name="LODY">2</token>
					<Content name="MeshId"><url>'.$hatmesh.'</url></Content>
					<token name="MeshType">5</token>
					<string name="Name">Mesh</string>
					<Vector3 name="Offset">
						<X>0</X>
						<Y>0</Y>
						<Z>0</Z>
					</Vector3>
					<Vector3 name="Scale">
						<X>1</X>
						<Y>1</Y>
						<Z>1</Z>
					</Vector3>
					<Content name="TextureId"><url>'.$hattexture.'</url></Content>
					<Vector3 name="VertexColor">
						<X>1</X>
						<Y>1</Y>
						<Z>1</Z>
					</Vector3>
				</Properties>
			</Item>
		</Item>
	</Item>
    
</roblox>';

$xml = str_replace(
    ['{hatx}', '{haty}', '{hatz}'],
    [$hatx, $haty, $hatz],
    $xml
);






echo $xml;

?>