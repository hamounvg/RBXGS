<?php
// api/AssetProxy.php

$ROBLOX_COOKIE = "_|WARNING:-DO-NOT-SHARE-THIS..."; // <-- PUT YOUR COOKIE HERE

function log_msg($msg) {
    // file_put_contents("asset_log.txt", date("[H:i:s] ") . $msg . "\n", FILE_APPEND);
}

error_reporting(E_ALL); 
ini_set('display_errors', 0);
if (ob_get_level()) ob_end_clean();

function fetch_raw($url, $cookie) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_COOKIE, ".ROBLOSECURITY=" . $cookie);
    curl_setopt($ch, CURLOPT_USERAGENT, "Roblox/WinInet");
    $data = curl_exec($ch);
    $info = curl_getinfo($ch);
    curl_close($ch);
    
    if ($info['http_code'] == 200 && !empty($data)) {
        return $data;
    }
    return false;
}

function convert_to_png($imgData) {
    if (!extension_loaded('gd')) return false;

    // Load image from string (supports jpg, png, gif, webp, etc.)
    $im = @imagecreatefromstring($imgData);
    if (!$im) return false;

    $width = imagesx($im);
    $height = imagesy($im);

    $newWidth = ($width < 512) ? 512 : $width;
    $newHeight = ($height < 512) ? 512 : $height;

    $newImg = imagecreatetruecolor($newWidth, $newHeight);

    imagealphablending($newImg, false);
    imagesavealpha($newImg, true);
    $transparent = imagecolorallocatealpha($newImg, 255, 255, 255, 127);
    imagefilledrectangle($newImg, 0, 0, $newWidth, $newHeight, $transparent);

    imagecopyresampled($newImg, $im, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);

    ob_start();
    imagepng($newImg);
    $finalData = ob_get_contents();
    ob_end_clean();

    imagedestroy($im);
    imagedestroy($newImg);

    return $finalData;
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$dlUrl = "https://assetdelivery.roblox.com/v1/asset/?id=" . $id;
$data = fetch_raw($dlUrl, $ROBLOX_COOKIE);

if ($data) {
    if (substr(trim($data), 0, 1) === "<") {
        if (preg_match('/id=([0-9]+)/', $data, $matches)) {
            $realImageId = $matches[1];
            if ($realImageId != $id) {
                $realUrl = "https://assetdelivery.roblox.com/v1/asset/?id=" . $realImageId;
                $innerData = fetch_raw($realUrl, $ROBLOX_COOKIE);
                if ($innerData) $data = $innerData;
            }
        }
    }

    $pngData = convert_to_png($data);

    if ($pngData) {
        header("Content-Type: image/png");
        echo $pngData;
    } else {
        header("Content-Type: application/octet-stream");
        echo $data;
    }
    exit;
}

header("Content-Type: image/png");
echo base64_decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8/5+hHgAHggJ/PchI7wAAAABJRU5ErkJggg==");
?>