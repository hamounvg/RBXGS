<?php
error_reporting(0);
ob_clean(); 

header("Content-Type: text/xml");

$head = isset($_GET['head']) ? (int)$_GET['head'] : 24;
$torso = isset($_GET['torso']) ? (int)$_GET['torso'] : 23;
$larm = isset($_GET['larm']) ? (int)$_GET['larm'] : 24;
$rarm = isset($_GET['rarm']) ? (int)$_GET['rarm'] : 24;
$lleg = isset($_GET['lleg']) ? (int)$_GET['lleg'] : 119;
$rleg = isset($_GET['rleg']) ? (int)$_GET['rleg'] : 119;

$tshirt = isset($_GET['tshirt']) ? $_GET['tshirt'] : "";
$tmode  = isset($_GET['tmode']) ? $_GET['tmode'] : "proxy";

echo '<?xml version="1.0" encoding="utf-8"?>';
?>
<roblox xmlns:xmime="http://www.w3.org/2005/05/xmlmime" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="http://www.roblox.com/roblox.xsd" version="4">
	<External>null</External>
	<External>nil</External>
	<Item class="BodyColors">
		<Properties>
			<string name="Name">Body Colors</string>
			<int name="HeadColor"><?php echo $head; ?></int>
			<int name="TorsoColor"><?php echo $torso; ?></int>
			<int name="LeftArmColor"><?php echo $larm; ?></int>
			<int name="RightArmColor"><?php echo $rarm; ?></int>
			<int name="LeftLegColor"><?php echo $lleg; ?></int>
			<int name="RightLegColor"><?php echo $rleg; ?></int>
		</Properties>
	</Item>
    <?php if(!empty($tshirt) && $tshirt != "0"): ?>
    <Item class="ShirtGraphic">
        <Properties>
            <string name="Name">ShirtGraphic</string>
            <Content name="Graphic">
                <url><?php 
                    if ($tmode == "direct") {
                        echo htmlspecialchars($tshirt); 
                    } else {
                        echo "http://127.0.0.1/asset.php?id=" . (int)$tshirt;
                    }
                ?></url>
            </Content>
        </Properties>
    </Item>
    <?php endif; ?>
</roblox>