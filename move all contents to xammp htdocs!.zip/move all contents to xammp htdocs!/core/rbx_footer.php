<div id="Footer" style="float: left">
	<hr>
	<p class="Legalese">
		GAMMA, "Old ROBLOX Revival", does not own the original clients source maintainers other than the changes done to their software.<br>
		This would be fair use as we are not driven by monetary gain, but rather for the sake of fun. Created by 
		<a href="/info/About.aspx">Zlysie</a>, ©2008.<br>
		I am not affiliated with ROBLOXs Corporation. I am just making an old client they don't care about work again.<br>
		Use of this site signifies your acceptance of the
		<a href="/info/TermsOfService.aspx">Terms and Conditions</a>.<br>
		<a href="/info/Privacy.aspx">Privacy Policy</a>
		&nbsp;|&nbsp; <a href="mailto:realoikmo@gmail.com">Contact Us</a> &nbsp;|&nbsp;
		<a href="/info/About.aspx">About Us</a>
	</p>
</div>